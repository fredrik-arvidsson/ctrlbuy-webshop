package com.ctrlbuy.webshop.exception;

public class ControllerAdvice {
}
