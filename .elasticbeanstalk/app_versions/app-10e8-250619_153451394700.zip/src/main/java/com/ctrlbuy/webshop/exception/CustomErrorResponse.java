package com.ctrlbuy.webshop.exception;

import java.time.LocalDateTime;

public class CustomErrorResponse {
    private LocalDateTime timestamp;
    private int status;
    private String error;
    private String message;
    private String path;

    // Konstruktörer, getters och setters
}
