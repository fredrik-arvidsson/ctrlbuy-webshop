package com.ctrlbuy.webshop.service;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class UserServiceTest {

    @Test
    void testUserServiceExists() {
        assertTrue(true);
        System.out.println("✅ UserService test fungerar!");
    }

    @Test
    void testBasicValidation() {
        assertEquals(10, 5 + 5);
        System.out.println("✅ UserService matematik test fungerar!");
    }
}
