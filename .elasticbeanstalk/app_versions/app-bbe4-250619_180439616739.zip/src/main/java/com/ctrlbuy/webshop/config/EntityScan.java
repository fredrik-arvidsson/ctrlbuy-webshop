package com.ctrlbuy.webshop.config;

public @interface EntityScan {
    String basePackages();
}
