package com.ctrlbuy.webshop.service;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ProductServiceTest {

    @Test
    void testBasic() {
        assertTrue(true);
        System.out.println("✅ ProductService test fungerar!");
    }

    @Test 
    void testMath() {
        assertEquals(4, 2 + 2);
        System.out.println("✅ ProductService matematik test fungerar!");
    }
}
